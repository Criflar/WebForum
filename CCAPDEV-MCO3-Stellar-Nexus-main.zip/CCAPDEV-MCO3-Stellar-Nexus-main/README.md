To run the web forum application locally, here are the steps:

PREREQUISITES: Node.js 

1. Open a terminal in the project directory
2. Run npm install to install all dependencies
3. Run node app.js to start the server
4. Go to localhost:3000 on a web browser to run the application
